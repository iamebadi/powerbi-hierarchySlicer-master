# Power BI HierachySlicer 

[![Build Status](https://travis-ci.org/liprec/powerbi-hierarchySlicer.svg?branch=master)](https://travis-ci.org/liprec/powerbi-hierarchySlicer)

Home for my Power BI Custom Visual: HierarchySlicer