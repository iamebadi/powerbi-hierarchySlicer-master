module powerbi.visuals.plugins {
    export var PBI_CV_B232C01E_3021_4106_B09E_42929DAC879C_DEBUG = {
        name: 'PBI_CV_B232C01E_3021_4106_B09E_42929DAC879C_DEBUG',
        displayName: 'HierarchySlicer',
        class: 'HierarchySlicer',
        version: '1.0.0',
        apiVersion: '1.7.0',
        create: (options: extensibility.visual.VisualConstructorOptions) => new powerbi.extensibility.visual.PBI_CV_B232C01E_3021_4106_B09E_42929DAC879C.HierarchySlicer(options),
        custom: true
    };
}
